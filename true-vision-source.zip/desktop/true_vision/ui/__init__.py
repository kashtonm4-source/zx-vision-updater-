"""TRUE VISION desktop widgets."""
